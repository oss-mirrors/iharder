#import "Controller.h"

@implementation Controller

- (void)start:(id)sender{ [self start:sender targetProxy:nil]; }
- (id)start:(id)arg1 targetProxy:(id)pseudoSelf
{
    // Button click
    if( arg1 == _startButton )
    {
        NSLog(@"Button clicked in %@", [NSThread currentThread]);
        
        // Prepare GUI components
        [_startButton setEnabled:NO];
        [_input setEnabled:NO];
        [_status setStringValue:@"Fake preparation..."];
        [_pi setIndeterminate:YES];
        [_pi startAnimation:self];
        
        // Start work on new thread
        [ThreadWorker workOn:self
                withSelector:@selector(start:targetProxy:)
                withObject:nil
                didEndSelector:@selector(start:)];
    }   // end if: button click

    // Long task
    else if( pseudoSelf )
    {
        int i;

        NSLog(@"Long task working in %@", [NSThread currentThread]);
        
        // Initial (fake) pause
        [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:1.0]];

        // Fake work
        [_status setStringValue:@"Fake working on long task..."];
        for( i = 0; i <= 100; i++ )
        {
            [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.02]];
            [pseudoSelf start:[NSNumber numberWithDouble:(i*1.0)]];
        }   // end for: work
        
        return @"Look what I did!";
    }   // end else if: long task

    // Update
    else if( [arg1 isKindOfClass:[NSNumber class]] )
    {
        if( [_pi isIndeterminate] )
        {
            NSLog(@"First update in %@", [NSThread currentThread]);
            
            [_pi stopAnimation:self];
            [_pi setIndeterminate:NO];
        }   // end if: turning on determinate
        
        [_pi setDoubleValue:[arg1 doubleValue]];
    }   // end else if: update

    // Finished.
    else
    {
        NSLog(@"Long task finishing in %@", [NSThread currentThread]);
        
        [_status setStringValue:[@"Finished with message: " stringByAppendingString:arg1]];
        [_input setEnabled:YES];
        [_pi setIndeterminate:YES];
        [_startButton setEnabled:YES];
    }   // end else: finished
    return nil;
}   // end start

@end
