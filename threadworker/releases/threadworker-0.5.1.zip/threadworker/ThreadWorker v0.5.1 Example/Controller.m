#import "Controller.h"

@implementation Controller

- (void)start:(id)sender{ [self start:sender tw:nil]; }
- (id)start:(id)arg1 tw:(ThreadWorker *)tw
{
    // Button click
    if( arg1 == _startButton )
    {
        // Prepare GUI components
        [_startButton setEnabled:NO];
        [_input setEnabled:NO];
        [_status setStringValue:@"Fake preparation..."];
        [_pi setIndeterminate:YES];
        [_pi startAnimation:self];
        
        // Start work on new thread
        [ThreadWorker workOn:self
                withSelector:@selector(start:tw:)
                withArgument:nil
              didEndSelector:@selector(start:)];
    }   // end if: button click

    // Long task
    else if( tw )
    {
        int i;
        
        // Initial (fake) pause
        [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:1.0]];

        // Fake work
        [_status setStringValue:@"Fake working on long task..."];
        for( i = 0; i <= 100; i++ )
        {
            [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.02]];
            [tw runSelectorInCallingThread:@selector(start:) withObject:[NSNumber numberWithDouble:(i*1.0)]];
        }   // end for: work
        
        return @"Look what I did!";
    }   // end else if: long task

    // Update
    else if( [arg1 isKindOfClass:[NSNumber class]] )
    {
        if( [_pi isIndeterminate] )
        {
            [_pi stopAnimation:self];
            [_pi setIndeterminate:NO];
        }   // end if: turning on determinate
        
        [_pi setDoubleValue:[arg1 doubleValue]];
    }   // end else if: update

    // Finished.
    else
    {
        [_status setStringValue:[@"Finished with message: " stringByAppendingString:arg1]];
        [_input setEnabled:YES];
        [_pi setIndeterminate:YES];
        [_startButton setEnabled:YES];
    }   // end else: finished
    return nil;
}   // end start

@end
