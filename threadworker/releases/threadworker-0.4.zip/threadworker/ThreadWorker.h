// You'll nee to include one of the following two lines.
// Try each one to see which one works for you.
#import <AppKit/AppKit.h>
//#import <Cocoa/Cocoa.h>



/**
 * ThreadWorker v0.4
 *
 * Usage:
 * 
 *     [ThreadWorker 
 *         workOn:self 
 *         withSelector:@selector(longTask:) 
 *         withArgument:someData
 *         didEndTarget:self
 *         didEndSelector:@selector(longTaskFinished:) ];
 *
 * The ThreadWorker class was designed to be simple and
 * to make multi-threading even simpler. You can offload
 * tasks to another thread and be notified when the task
 * is finished.
 * 
 * In this sense it is similar to the Java SwingWorker
 * class, though the need for such a class in Cocoa
 * and Objective-C is as different as the implementation.
 *
 * Be sure to copy the ThreadWorker.h and ThreadWorker.m
 * files to your project directory.
 *
 * To see how to use this class, see the documentation for
 * the "workOn" method below.
 *
 * I'm releasing this code into the Public Domain.
 * Do with it as you will. Enjoy!
 *
 * Original author: Robert Harder, rharder@usa.net
 *
 *
 * Change History
 *
 * 0.4 - Released into the Public Domain. Enjoy!
 *
 * 0.3 - Permitted "workOn" method to accept a second argument of type
 *       ThreadWorker* to allow for passing of the parent ThreadWorker
 *       to the secondary thread. This makes it easy and reliable to
 *       call other methods on the calling thread.
 *
 * 0.2 - Added runSelectorInCallingThread so that you could make calls
 *       back to the main, i.e. calling, thread from the secondary thread.
 *
 * 0.1 - Initial release.
 *
 */




@interface ThreadWorker : NSObject
{
   id            _target;          // The object whose selector will be called
   SEL           _selector;        // The selector that will be called in another thread
   id            _argument;        // The argument that will be passed to the selector
   NSRunLoop    *_runLoop;         // The run loop that will post the final notice
   id            _didEndTarget;    // Target for final notice
   SEL           _didEndSelector;  // Selector for final notice
}



/**
 * Call this class method to work on something in another thread. 
 * 
 * Example:
 *
 *     [ThreadWorker workOn:self 
 *                   withSelector:@selector(longTask:) 
 *                   withArgument:someData
 *                   didEndTarget:self
 *                   didEndSelector:@selector(longTaskFinished:)];
 *
 * 
 * The longTask method in self will then be called and should look something like this:
 *
 *     - (id)longTask:(id)argument
 *     {
 *         // Dictionary to store info that will be passed to NSNotificationCenter
 *         NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithCapacity:0];
 *
 *         // Do something that takes a while
 *         // ...
 *
 *         return userInfo;
 *     }    
 *
 * Optionally you can have this "longTask" method accept a second argument of type
 * ThreadWorker* which will give you access to the parent ThreadWorker and thus
 * make it safe and reliable to use it to call selectors in the calling thread.
 * Your "longTask" method might then look like this:
 *
 *     - (id)longTask:(id)argument tw:(ThreadWorker *)parentTW
 *
 * You don't have to name your parameter "tw." You only have to match what you
 * name it to the selector you passed earlier:
 *
 *     [ThreadWorker workOn:self 
 *                   withSelector:@selector(longTask: tw:) 
 *                   withArgument:someData
 *                   didEndTarget:self
 *                   didEndSelector:@selector(longTaskFinished:)];
 *
 * Note: As of version 0.3, you should not rely on using the return
 * value of the class method [ThreadWorker workOn:...] if you plan to
 * use that variable immediately in your new thread.
 * If you use the saved value (in the case below,
 * it's the variable "tw") in the secondary thread, it's possible you will
 * reference it before the calling method has returned and the value of "tw"
 * has actually been saved. You would then be attempting to send a message
 * to "tw" which would have a nil value. That's not what you want.
 *
 * Note (cont'd): Instead, in the method that will be running in another thread,
 * you should give it a second parameter that accepts an argument of type
 * ThreadWorker* (as mentioned above).
 *
 * 
 * When your longTask method is finished, whatever is returned from it will
 * be passed to the didEndSelector (if it's not nil) as that selector's
 * only argument. The didEndSelector will be called on the original thread,
 * so if you launched the thread as a result of a user clicking on something,
 * the longTaskFinished will be called on the main thread, which is what you
 * need if you want to then modify any GUI components.
 * The longTaskFinished method might look something like this, then:
 *
 *     - (void)longTaskFinished:(id)userInfo
 *     {
 *         //Do something now that the thread is done
 *         // ...
 *     }    
*
 * Of course you will have to have imported the ThreadWorker.h
 * file in your class's header file. The top of your header file
 * might then look like this:
 *
 *     import <Cocoa/Cocoa.h>
 *     import "ThreadWorker.h"
 *
 * Enjoy.
 * 
 */
+ (ThreadWorker *)
    workOn:(id)target 
    withSelector:(SEL)selector 
    withArgument:(id)argument
    didEndTarget:(id)didEndTarget 
    didEndSelector:(SEL)didEndSelector;



/**
 * If you retained a reference to the ThreadWorker using the techniques
 * mentioned above, you can have your secondary thread call a method
 * in your calling thread. This is useful if you need to update
 * a GUI component (which is not thread-safe) from your secondary thread.
 *
 *     // Inside your long task
 *     [parentTW runSelectorInCallingThread:@selector(setStringValue:) 
 *         target:status 
 *         argument:@"WooHoo!"];
 *
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target argument:(id)argument;



/**
 * A variant of the main runSelectorInCallingThread method, this one
 * allows you to pass a double - useful if you're sending a message
 * to say an NSProgressIndicator.
 *
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target doubleArgument:(double)doubleNum;




/**
 * A variant of the main runSelectorInCallingThread method, this one
 * allows you to pass an int.
 *
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target intArgument:(int)intNum;




/**
* A variant of the main runSelectorInCallingThread method, this one
* allows you to pass a boolean.
*
*/
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target booleanArgument:(BOOL)boolState;



/**
 * Just a little note to say, "Good job, Rob!" to
 * the original author of this Public Domain software.
 */
+ (NSString *)description;



@end
