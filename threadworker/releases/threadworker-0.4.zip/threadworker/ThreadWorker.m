#import "ThreadWorker.h"


@interface ThreadWorker (PrivateAPI)

/**
 * Only legitimate initialization routine.
 */
- (ThreadWorker *)  initWithTarget:(id)target 
                    selector:(SEL)selector 
                    argument:(id)argument
                    runLoop:(NSRunLoop *)runLoop
                    didEndTarget:(id)didEndTarget
                    didEndSelector:(SEL)didEndSelector;

/**
 * Called from a timer in the calling thread (as opposed
 * to the newly-created secondary thread).
 */
- (void) internalRunSelectorInCallingThread:(NSTimer *)timer;

/**
 * This is the method that is first detached in another thread.
 */
- (void) startThread:(id)argNotUsed;

/**
 * Make sure we clean up after ourselves.
 */
- (void) dealloc;

@end // PrivateAPI




@implementation ThreadWorker


/**
 * This is a public class method that you call 
 * to kick off a task in a new thread.
 */
+ (ThreadWorker *) workOn:(id)target 
                   withSelector:(SEL)selector 
                   withArgument:(id)argument
                   didEndTarget:(id)didEndTarget        // Optional
                   didEndSelector:(SEL)didEndSelector;  // Optional
{
    ThreadWorker *tw;

    // Make sure the target has that selector
    if( ![target respondsToSelector:selector] )
    {	NSLog( @"\nThreadWorker reports: Target %@ does not respond to selector %@\n", target, selector );
        return nil;
    }   // end if: error

    // Create an instance of ThreadWorker
    tw = [[[ThreadWorker alloc] 
            initWithTarget:target 
            selector:selector 
            argument:argument
            runLoop:[NSRunLoop currentRunLoop]
            didEndTarget:didEndTarget
            didEndSelector:didEndSelector] autorelease];

    // Launch thread in an internal selector that will handle the strange NSThread requirements.
    [NSThread detachNewThreadSelector:@selector(startThread:) toTarget:tw withObject:nil];

    return tw;
}   // end workOn




/**
 * Private init method that establishes instance variables.
 */
- (ThreadWorker *) initWithTarget:(id)target 
                   selector:(SEL)selector 
                   argument:(id)argument
                   runLoop:(NSRunLoop *)runLoop
                   didEndTarget:(id)didEndTarget
                   didEndSelector:(SEL)didEndSelector
{
    [super init];

    // Set instance variables
    _target   		= target;
    _selector		= selector;
    _argument 		= argument;
    _runLoop  		= runLoop;
    _didEndTarget 	= didEndTarget;
    _didEndSelector	= didEndSelector;

    // Retain instance variables
    [_target   		retain];
    [_argument 		retain];
    [_runLoop  		retain];
    [_didEndTarget	retain];

    return self;
}   // end initWithTarget


/**
 * When deallocating, release instance variables.
 */
- (void)dealloc
{
    // Release instance variables
    [_target        release];
    [_argument      release];
    [_runLoop       release];
    [_didEndTarget  release];
    
    // Clear instance variables - Probably unnecessary.
    _target         = nil;
    _argument       = nil;
    _runLoop        = nil;
    _didEndTarget   = nil;
}	// end dealloc




/**
 * Private method that is called in a detached thread.
 * It sets up the thread maintenance - primarily the
 * auto release pool - and calls the user's method.
 */
- (void)startThread:(id)argNotUsed
{
    id                   userInfo;
    NSAutoreleasePool   *pool;

    // Thread startup maintenance
    pool     = [[NSAutoreleasePool alloc] init];

    // Call user's selector with a ThreadWorker argument, if a second argument is taken
    if( [[_target methodSignatureForSelector:_selector] numberOfArguments] == 4 ) // 2 hidden + 2 exposed
        userInfo = [_target performSelector:_selector withObject:_argument withObject:self];
    else
        userInfo = [_target performSelector:_selector withObject:_argument];
    
    // Call finalizing method in calling thread
    [self   runSelectorInCallingThread:_didEndSelector
            target:_didEndTarget
            argument:userInfo];
            
    // Clean up thread maintenance
    [pool release];
    [NSThread exit];
}   // end startThread




/**
 * Public method that calls a method (selector) in the calling
 * thread's run loop. This is used internally but can also be
 * used in your code if you need to access the main thread from
 * your secondary thread.
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target argument:(id)argument
{
    // Build dictionary necessary to call 
    // selector after the timer is fired.
    NSDictionary *dict;
    
    dict = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSValue valueWithBytes:&selector objCType:@encode(SEL)], @"selector",
                         target,    @"target",
                         argument,  @"argument", nil];
    
    // Schedule timer in calling thread
    [_runLoop 
        addTimer:[NSTimer timerWithTimeInterval:0 
                          target:self 
                          selector:@selector(internalRunSelectorInCallingThread:) 
                          userInfo:dict 
                          repeats:NO] 
        forMode:NSDefaultRunLoopMode];

}   // end runSelectorInCallingThread



/**
 * Public method similar to main runSelectorInCallingThread method except that
 * this one lets you pass a double value as the argument.
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target doubleArgument:(double)num
{
    // Build dictionary necessary to call 
    // selector after the timer is fired.
    NSDictionary *dict;
    
    dict = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSValue valueWithBytes:&selector objCType:@encode(SEL)], @"selector",
                         target,    @"target",
                         [NSNumber numberWithDouble:num],  @"argument", 
                         @"double", @"altType", nil];
    
    // Schedule timer in calling thread
    [_runLoop 
        addTimer:[NSTimer timerWithTimeInterval:0 
                          target:self 
                          selector:@selector(internalRunSelectorInCallingThread:) 
                          userInfo:dict 
                          repeats:NO] 
        forMode:NSDefaultRunLoopMode];
        
}   // end runSelectorInCallingThread



/**
 * Public method similar to main runSelectorInCallingThread method except that
 * this one lets you pass an int value as the argument.
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target intArgument:(int)num
{
    // Build dictionary necessary to 
    // call selector after the timer is fired.
    NSDictionary *dict;

    dict = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSValue valueWithBytes:&selector objCType:@encode(SEL)], @"selector",
                         target,   @"target",
                         [NSNumber numberWithInt:num],  @"argument", 
                         @"int",   @"altType", nil];

    // Schedule timer in calling thread
    [_runLoop 
        addTimer:[NSTimer timerWithTimeInterval:0 
                          target:self 
                          selector:@selector(internalRunSelectorInCallingThread:) 
                          userInfo:dict 
                          repeats:NO] 
        forMode:NSDefaultRunLoopMode];
}   // end runSelectorInCallingThread



/**
 * Public method similar to main runSelectorInCallingThread method except that
 * this one lets you pass a boolean value as the argument.
 */
- (void)runSelectorInCallingThread:(SEL)selector target:(id)target booleanArgument:(BOOL)boolState
{
    // Build dictionary necessary to 
    // call selector after the timer is fired.
    NSDictionary *dict;

    dict = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSValue valueWithBytes:&selector objCType:@encode(SEL)], @"selector",
                         target,       @"target",
                         [NSNumber numberWithBool:boolState],   @"argument", 
                         @"boolean",   @"altType", nil];

    // Schedule timer in calling thread
    [_runLoop 
        addTimer:[NSTimer timerWithTimeInterval:0 
                          target:self 
                          selector:@selector(internalRunSelectorInCallingThread:) 
                          userInfo:dict 
                          repeats:NO] 
        forMode:NSDefaultRunLoopMode];
}   // end runSelectorInCallingThread




/**
 * Private method that responds to timer and runs in calling thread.
 */
- (void)internalRunSelectorInCallingThread:(NSTimer *)timer
{
    // Deconstruct dictionary to call selector
    NSDictionary    *userInfo   = [timer userInfo];
    id               target     = [userInfo objectForKey:@"target"];
    id               argument   = [userInfo objectForKey:@"argument"];
    SEL              selector;
    double           altDoubleNum;
    int              altIntNum;
    BOOL             altBoolean;
    NSInvocation    *invocation;
    NSString        *altType    = [userInfo objectForKey:@"altType"];
    
    // Set selector that doesn't use
    [[userInfo objectForKey:@"selector"] getValue:&selector];
    
    // If no alternate argument type was sent, send as object
    if( !altType )
        [target performSelector:selector withObject:argument];
     
    // Double   
    else if( [altType isEqualToString:@"double"] )
    {
        altDoubleNum  = [argument doubleValue];
        invocation    = [NSInvocation invocationWithMethodSignature:
                         [target methodSignatureForSelector:selector]];
        
        [invocation setTarget:target];
        [invocation setSelector:selector];
        [invocation setArgument:&altDoubleNum atIndex:2];
        [invocation invoke];
    }   // end else: send as double

    // Int
    else if( [altType isEqualToString:@"int"] )
    {
        altDoubleNum  = [argument doubleValue];
        invocation    = [NSInvocation invocationWithMethodSignature:
                         [target methodSignatureForSelector:selector]];
        [invocation setTarget:target];
        [invocation setSelector:selector];
        [invocation setArgument:&altIntNum atIndex:2];
        [invocation invoke];
    }   // end else: send as double

    // Boolean
    else if( [altType isEqualToString:@"boolean"] )
    {
        altBoolean  = [argument boolValue];
        invocation  = [NSInvocation invocationWithMethodSignature:
                       [target methodSignatureForSelector:selector]];
        [invocation setTarget:target];
        [invocation setSelector:selector];
        [invocation setArgument:&altBoolean atIndex:2];
        [invocation invoke];
    }   // end else: send as boolean

}   // end internalRunSelectorInCallingThread


/**
 * Just a little note to say, "Good job, Rob!" to
 * the original author of this Public Domain software.
 */
+ (NSString *)description
{   return @"ThreadWorker v0.4. Public Domain. Original author: Robert Harder, rharder@usa.net. Keep up-to-date at http://iHarder.net";
}   // end description




@end
