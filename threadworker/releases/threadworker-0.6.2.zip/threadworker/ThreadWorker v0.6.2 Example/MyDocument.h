//
//  MyDocument.h
//  ThreadWorker v0.5.1
//
//  Created by Robert Harder on Mon Feb 04 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//
 

#import <Cocoa/Cocoa.h>

@interface MyDocument : NSDocument
{
}
@end
