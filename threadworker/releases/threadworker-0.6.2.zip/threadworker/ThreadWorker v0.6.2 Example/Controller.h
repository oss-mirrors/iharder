#import <AppKit/AppKit.h>
#import "ThreadWorker.h"

@interface Controller : NSObject
{
    id _input;
    id _pi;
    id _startButton;
    id _status;
}

- (id)setStatus:(NSString *)status;
- (void) start:(id)sender;
- (id)   start:(id)arg1 targetProxy:(id)pseudoSelf;
@end
