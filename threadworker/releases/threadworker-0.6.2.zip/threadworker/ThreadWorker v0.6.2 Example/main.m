//
//  main.m
//  ThreadWorker v0.6
//
//  Created by Robert Harder on Mon Feb 04 2002.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
